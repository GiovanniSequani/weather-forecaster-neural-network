from wwo_hist_updated import retrieve_hist_data

frequency = 1
start_date = '1/1/2010'
end_date = '27/9/2023'
api_key = '61d88074833245ecbb9135659243004'
location_list = ['padova']
hist_weather_data = retrieve_hist_data(api_key,
                                location_list,
                                start_date,
                                end_date,
                                frequency,
                                location_label = False,
                                export_csv = False,
                                store_df = True)

hist_weather_data[0].to_csv("padova.csv")
